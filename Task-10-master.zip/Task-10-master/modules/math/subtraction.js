function substraction(a, b) {
  return a - b;
}

export default substraction;
